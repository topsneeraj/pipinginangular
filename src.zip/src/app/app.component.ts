import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'pipingexample';

   price = 113;
   somedate = "10-02-2018";
   val1 = 12.45;
   obj =[{'empname':'tops','empadd':'surat'}];
   someval = "this is topstech";
   
   val2 = 12;
   sometext = "topstechnologiessurat";
   




}
